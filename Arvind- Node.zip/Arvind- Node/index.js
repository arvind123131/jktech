const axios = require('axios'); // For HTTP requests 
const cheerio = require('cheerio'); // For parsing HTML 
const fs = require('fs'); // For file operations 
const pLimit = require('p-limit').default; // For concurrency control 

// Input: List of Wikipedia URLs 
const urls = [
    'https://en.wikipedia.org/wiki/India',
    'https://en.wikipedia.org/wiki/United_States',
    'https://en.wikipedia.org/wiki/United_Kingdom'
    ];

// concurrency level 
const concurrencyLimit = 3;

// Function to fetch and count words
async function fetchAndCountWords(url) {
    try {
        const response = await axios.get(url);
        const data = cheerio.load(response.data);
        const text = data('body').text(); // Extract all text from the body 
        const wordCount = text.split(/\s+/).filter(word => word).length; // Count words 
        return { url, wordCount };
    } catch (error) {
        console.error(`Error fetching ${url}:`, error.message);
        return { url, wordCount: 0 };
    }
}

// Process all URLs concurrently with the specified limit 
async function processUrls(urls, concurrencyLimit) {
    const limit = pLimit(3); 
    const tasks = urls.map(url => limit(() => fetchAndCountWords(url)));
    // Wait for all tasks to complete 
    const results = await Promise.all(tasks); // Write results to file 
    const output = results.map(({ url, wordCount }) => `${url}, ${wordCount}`).join('\n'); 
    fs.writeFileSync('results.txt', output); 
    console.log("Results saved to results.txt");
}
// Start processing 
processUrls(urls, concurrencyLimit)